#Trendy NUM.

n=input()
if(len(n)==3 and int(n[1])%3==0):
    print(n,"is a trendy number")